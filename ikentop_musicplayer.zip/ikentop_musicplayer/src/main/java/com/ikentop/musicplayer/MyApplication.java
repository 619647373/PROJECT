package com.ikentop.musicplayer;

import android.app.Application;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.ikentop.musicplayer.reciver.MyPlayerReceiver;
import com.ximalaya.ting.android.opensdk.datatrasfer.CommonRequest;
import com.ximalaya.ting.android.opensdk.player.appnotification.XmNotificationCreater;
import com.ximalaya.ting.android.opensdk.util.BaseUtil;

/**
 * Created by lwj on 2017/12/6.
 */

public class MyApplication extends Application {

    public static final String TAG = "debugs";

    private static MyApplication mApplication;

    public static MyApplication getInstance() {
        return mApplication;
    }

    private SharedPreferences sp;

    @Override
    public void onCreate() {
        super.onCreate();
        mApplication = this;
        // CommonRequest.getInstanse().init(this, "4568d629d8559dc49dfde6d5a86b3767");

        if (BaseUtil.isMainProcess(MyApplication.getInstance())) {
            CommonRequest mXimalaya = CommonRequest.getInstanse();
            String mAppSecret;

            mAppSecret = "4568d629d8559dc49dfde6d5a86b3767";
            mXimalaya.setAppkey("91101cfe430eacac2067fa93a39b0ed7");
            mXimalaya.setPackid("com.ikentop.musicplayer");

            mXimalaya.init(this, mAppSecret);
        }


        sp = getSharedPreferences("loobot", MODE_PRIVATE);

    }

    public void saveValue(String key, String value) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public String getStrValue(String key) {
        return sp.getString(key, null);
    }

    public void saveToken(String value) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("token", value);
        editor.commit();
    }

    public String getToken() {
        return sp.getString("token", null);
    }

    public boolean getBooleanValue(String key) {
        return sp.getBoolean(key, false);
    }

    public boolean getBooleanValue(String key, boolean defaultValue) {
        return sp.getBoolean(key, defaultValue);
    }
}
