package com.ikentop.musicplayer.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;

import com.ikentop.musicplayer.R;
import com.ikentop.musicplayer.utils.StatusBarCompat;

/**
 * Created by lwj on 2017/12/13.
 */

public class BaseActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        StatusBarCompat.compat(this, getResources().getColor(R.color.color_topic));
    }
}
