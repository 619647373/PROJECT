package com.ikentop.musicplayer.activity;

import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.ikentop.musicplayer.MyApplication;
import com.ikentop.musicplayer.R;
import com.ikentop.musicplayer.bean.Model_ZiliaokuThree;
import com.ikentop.musicplayer.utils.DisplayUtil;
import com.ikentop.musicplayer.utils.IToast;
import com.ikentop.musicplayer.utils.PlayerOnlineUtil;
import com.ikentop.musicplayer.utils.SimpleDateUtils;
import com.ikentop.musicplayer.view.RoundImageView;
import com.ximalaya.ting.android.opensdk.constants.DTransferConstants;
import com.ximalaya.ting.android.opensdk.datatrasfer.CommonRequest;
import com.ximalaya.ting.android.opensdk.datatrasfer.IDataCallBack;
import com.ximalaya.ting.android.opensdk.model.PlayableModel;
import com.ximalaya.ting.android.opensdk.model.live.radio.Radio;
import com.ximalaya.ting.android.opensdk.model.live.schedule.Schedule;
import com.ximalaya.ting.android.opensdk.model.track.Track;
import com.ximalaya.ting.android.opensdk.model.track.TrackList;
import com.ximalaya.ting.android.opensdk.player.XmPlayerManager;
import com.ximalaya.ting.android.opensdk.player.service.IXmPlayerStatusListener;
import com.ximalaya.ting.android.opensdk.player.service.XmPlayListControl;
import com.ximalaya.ting.android.opensdk.player.service.XmPlayerConfig;
import com.ximalaya.ting.android.opensdk.player.service.XmPlayerException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author LUZI
 * @ClassName: PlayMusicActivity
 * @Description: TODO(播放流媒体音乐)
 * @date 2016/11/1
 */
public class PlayMusicActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.ll_playmode)
    public LinearLayout ll_playmode;
    @BindView(R.id.ll_back)
    LinearLayout ll_back;
    @BindView(R.id.ll_shangyiqu)
    LinearLayout ll_shangyiqu;
    @BindView(R.id.ll_play)
    LinearLayout ll_play;
    @BindView(R.id.ll_xiayiqu)
    LinearLayout ll_xiayiqu;
    @BindView(R.id.tv_musicname)
    TextView tv_musicname;
    @BindView(R.id.tv_auther)
    TextView tv_auther;
    @BindView(R.id.tv_playmusic_start)
    TextView tv_playmusic_start;
    @BindView(R.id.tv_playmusic_end)
    TextView tv_playmusic_end;
    @BindView(R.id.iv_musicimage)
    RoundImageView iv_musicimage;
    @BindView(R.id.iv_playmode)
    ImageView iv_playmode;
    @BindView(R.id.iv_play)
    ImageView iv_play;
    @BindView(R.id.iv_tongbu)
    ImageView iv_tongbu;
    @BindView(R.id.sb_volume)
    SeekBar sb_volume;
    @BindView(R.id.sb_progress)
    SeekBar sb_progress;
    private Animation animation;
    private ObjectAnimator anima;
    private PlayerOnlineUtil mPlayerOnlineUtil;
    private int plays = 0;
    private int playmodes = 0;
    private int maxVolume, currentVolume;
    private AudioManager mAudioManager;
    private DisplayUtil displayPic;
    protected static final int PROGRESS_CHANGED = 0x101;
    private ArrayList<Model_ZiliaokuThree.AudioinfosBean.ContentsBean> groups;
    Thread myVolThread = null;
    Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case PROGRESS_CHANGED:
                    setVolume();
                    break;
            }
        }
    };
    private String TAG = "PlayMusic";
    /**
     * 喜马拉雅播放器
     */
    private Context mContext;
    private String mAppSecret = "4568d629d8559dc49dfde6d5a86b3767";
    private XmPlayerManager mPlayerManager;
    private CommonRequest mXimalaya;
    private boolean mUpdateProgress = true;
    private int isximalay;
    private TrackList mTrackList = null;
    private int songPosition;
    private String ids;
    private boolean startmusic = true;
    private String xmlyString;
    private boolean random = true;
    private boolean isTongbu = true;

    public static PlayMusicActivity newInstance() {
        return new PlayMusicActivity();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playmusic);
        ButterKnife.bind(this);
//        startRotateImg();
        startObjectAnimation();
        anima.start();
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        setVolume();
        sb_volume.setOnSeekBarChangeListener(new SeekBarChangeVolume());
        new Thread(new myVolThread()).start();
        sb_progress.setOnSeekBarChangeListener(new SeekBarChangeEvent());
//        iv_play.setImageResource(R.drawable.icon_pause_circle);
        mPlayerOnlineUtil = new PlayerOnlineUtil(sb_progress, tv_playmusic_start, tv_playmusic_end);

        displayPic = new DisplayUtil();

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            Log.e(TAG, "喜马拉雅页面 ");
            songPosition = Integer.parseInt(bundle.getString("songPosition"));
            ids = bundle.getString("id");
            mContext = PlayMusicActivity.this;
            mXimalaya = CommonRequest.getInstanse();
            mPlayerManager = XmPlayerManager.getInstance(mContext);
            mPlayerManager.init();
            mPlayerManager.addPlayerStatusListener(mPlayerStatusListener);
            XmPlayerConfig.getInstance(mContext).setBreakpointResume(false);
//                getImei(ids+"");
            mPlayerManager.addOnConnectedListerner(new XmPlayerManager.IConnectListener() {
                @Override
                public void onConnected() {
                    // mPlayerManager.removeOnConnectedListerner(this);
                    //mPlayerManager.setPlayMode(XmPlayListControl.PlayMode.PLAY_MODEL_LIST_LOOP);
                    //Toast.makeText(PlayMusicActivity.this, "播放器初始化成功", Toast.LENGTH_SHORT).show();
                }
            });
            getTracks(ids);
        }

        //音乐播放完毕执行的方法
        mPlayerOnlineUtil.mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onCompletion(MediaPlayer mp) {
                // TODO Auto-generated method stub
                anima.pause();
                sb_progress.setProgress(0);
                iv_play.setImageResource(R.drawable.ic_play_circle_outline_white_48dp);
                //IToast.makeText(getString(R.string.playmusic_over));
            }
        });

    }

    //加载图片和歌曲
    public void LoodingInfo(final String icon, final String music) {

        if (!TextUtils.isEmpty(icon)) {
            displayPic.displayPic(this, icon, iv_musicimage);
        }
        new Thread(new Runnable() {

            @Override
            public void run() {
                if (!TextUtils.isEmpty(music)) {
                    mPlayerOnlineUtil.playUrl(music);
                }

            }
        }).start();
        iv_play.setImageResource(R.drawable.icon_pause_circle);
    }

    @OnClick({R.id.iv_tongbu, R.id.ll_playmode, R.id.ll_shangyiqu, R.id.ll_play,
            R.id.ll_xiayiqu, R.id.ll_back})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_playmode:
                if (playmodes == 1) {
                    mPlayerManager.setPlayMode(XmPlayListControl.PlayMode.PLAY_MODEL_LIST_LOOP);
                    playmodes = 0;
                    iv_playmode.setImageResource(R.drawable.ic_repeat_white);
                } else {
                    mPlayerManager.setPlayMode(XmPlayListControl.PlayMode.PLAY_MODEL_SINGLE);
                    playmodes = 1;
                    iv_playmode.setImageResource(R.drawable.icon_repeat_one);
                    IToast.makeText(getString(R.string.playmusic_danqu));
                }
                break;
            case R.id.ll_shangyiqu:
                mPlayerManager.playPre();
                mXimalaya.setDefaultPagesize(100);
                break;
            case R.id.ll_play:
                if (startmusic) {
                    new Thread(new Runnable() {

                        @Override
                        public void run() {
                            mPlayerManager.playList(mTrackList, songPosition);
                            Log.d(MyApplication.TAG, "ll_play----->" + mTrackList);
                        }
                    }).start();
                } else {
                    if (mPlayerManager.isPlaying()) {
                        mPlayerManager.pause();
                    } else {
                        mPlayerManager.play();
                    }
                }
                startmusic = false;
                break;
            case R.id.ll_xiayiqu:
                //喜马拉雅
                mPlayerManager.playNext();
                break;
            case R.id.ll_back:
                finish();
                break;
        }
    }

    /***设置选择动画*/
    private void startRotateImg() {
        animation = new RotateAnimation(0f, 360f, Animation.RESTART,
                0.5f, Animation.RESTART, 0.5f);
        animation.setDuration(10000);//设置动画持续时间
        animation.setRepeatCount(Animation.INFINITE);//设置重复次数
        animation.setStartTime(Animation.START_ON_FIRST_FRAME);//重复模式
        animation.setInterpolator(new LinearInterpolator());//设置匀速转动
        animation.setFillAfter(true);
        iv_musicimage.setAnimation(animation);
    }

    private void startObjectAnimation() {
        anima = ObjectAnimator.ofFloat(iv_musicimage, "rotation", 0f, 360f);
        anima.setDuration(100000);
        anima.setRepeatCount(ObjectAnimator.INFINITE);
        // 设置重复模式(RESTART或REVERSE),重复次数大于0或INFINITE生效
        anima.setRepeatMode(ObjectAnimator.RESTART);
        // 设置插值器(用于调节动画执行过程的速度 LinearInterpolator匀速 BounceInterpolator减速弹跳)
        anima.setInterpolator(new LinearInterpolator());
    }

    public void startAnimation(View view) {
        anima.start();
    }

    public void endAnimation(View view) {
        anima.end();
    }

    public void cancelAnimation(View view) {
        anima.cancel();
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void pauseAnimation(View view) {
        anima.pause();
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void resumeAnimation(View view) {
        anima.resume();
    }

    /***改变音乐播放进度*/
    class SeekBarChangeEvent implements SeekBar.OnSeekBarChangeListener {
        int progres;

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            if (isximalay == 1) {//喜马拉雅
                this.progres = progress * mPlayerOnlineUtil.mediaPlayer.getDuration()
                        / seekBar.getMax();
                float s = progress;
                float b = seekBar.getMax();
                float sp = (s / b * 100) * (mPlayerOnlineUtil.mediaPlayer.getDuration() / 1000);
                tv_playmusic_start.setText(mPlayerOnlineUtil.getStringTime((int) sp / 100));//暂停时拖拉进度条显示时间
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            if (isximalay == 0) {//喜马拉雅
                mUpdateProgress = false;
            }

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            if (isximalay == 0) {//喜马拉雅
                mPlayerManager.seekToByPercent(seekBar.getProgress() / (float) seekBar.getMax());
                mUpdateProgress = true;
            } else {
                mPlayerOnlineUtil.mediaPlayer.seekTo(progres);
            }
        }

    }

    /***改变音量进度*/
    class SeekBarChangeVolume implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress,
                    0);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            double q = seekBar.getProgress();
            double w = q / 10 * 15;
            long t = Math.round(w);
            System.out.println("------------->" + Math.round(w));
        }

    }

    /***设置音量进度*/
    private void setVolume() {
        maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        sb_volume.setMax(maxVolume);
        currentVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        sb_volume.setProgress(currentVolume);
    }

    class myVolThread implements Runnable {
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                Message message = new Message();
                message.what = PROGRESS_CHANGED;
                PlayMusicActivity.this.myHandler.sendMessage(message);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private IXmPlayerStatusListener mPlayerStatusListener = new IXmPlayerStatusListener() {

        @Override
        public void onSoundPrepared() {
            Log.e(TAG, "onSoundPrepared");
            sb_progress.setEnabled(true);
//            mProgress.setVisibility(View.GONE);
        }

        @Override
        public void onSoundSwitch(PlayableModel laModel, PlayableModel curModel) {
            Log.e(TAG, "onSoundSwitch index:");
            PlayableModel model = mPlayerManager.getCurrSound();
            if (model != null) {
                String title = null;
                String msg = null;
                String coverUrl = null;
                String coverSmall = null;
                if (model instanceof Track) {
                    Track info = (Track) model;
                    title = info.getTrackTitle();
                    msg = info.getAnnouncer() == null ? "" : info.getAnnouncer().getNickname();
                    coverUrl = info.getCoverUrlLarge();
                    coverSmall = info.getCoverUrlMiddle();
                } else if (model instanceof Schedule) {
                    Schedule program = (Schedule) model;
                    msg = program.getRelatedProgram().getProgramName();
                    title = program.getRelatedProgram().getProgramName();
                    coverUrl = program.getRelatedProgram().getBackPicUrl();
                    coverSmall = program.getRelatedProgram().getBackPicUrl();
                } else if (model instanceof Radio) {
                    Radio radio = (Radio) model;
                    title = radio.getRadioName();
                    msg = radio.getRadioDesc();
                    coverUrl = radio.getCoverUrlLarge();
                    coverSmall = radio.getCoverUrlSmall();
                }
                if (!TextUtils.isEmpty(title)) {
                    tv_musicname.setText(title);
                }
                if (!TextUtils.isEmpty(msg)) {
                    tv_auther.setText(msg);
                }
                if (!TextUtils.isEmpty(coverUrl)) {
                    displayPic.displayPic(PlayMusicActivity.this, coverUrl, iv_musicimage);
                }
            }
            updateButtonStatus();
        }


        private void updateButtonStatus() {
            if (mPlayerManager.hasPreSound()) {
                ll_shangyiqu.setEnabled(true);
            } else {
                ll_shangyiqu.setEnabled(false);
            }
            if (mPlayerManager.hasNextSound()) {
                ll_xiayiqu.setEnabled(true);
            } else {
                ll_shangyiqu.setEnabled(false);
            }
        }

        @Override
        public void onPlayStop() {
            Log.e(TAG, "onPlayStop");
            iv_play.setImageResource(R.drawable.ic_play_circle_outline_white_48dp);
        }

        @Override
        public void onPlayStart() {
            Log.e(TAG, "onPlayStart");
            iv_play.setImageResource(R.drawable.icon_pause_circle);
        }

        @Override
        public void onPlayProgress(int currPos, int duration) {
            String title = "";
            PlayableModel info = mPlayerManager.getCurrSound();
            if (info != null) {
                if (info instanceof Track) {
                    title = ((Track) info).getTrackTitle();
                } else if (info instanceof Schedule) {
                    title = ((Schedule) info).getRelatedProgram().getProgramName();
                } else if (info instanceof Radio) {
                    title = ((Radio) info).getRadioName();
                }
            }
            tv_playmusic_start.setText(SimpleDateUtils.formatTime(currPos));
            tv_playmusic_end.setText(SimpleDateUtils.formatTime(duration));
//            mTextView.setText(title + "[" + ToolUtil.formatTime(currPos) + "/" + ToolUtil.formatTime(duration) + "]");
            if (mUpdateProgress && duration != 0) {
                sb_progress.setProgress((int) (100 * currPos / (float) duration));
            }
        }

        @Override
        public void onPlayPause() {
            Log.e(TAG, "onPlayPause");
            iv_play.setImageResource(R.drawable.ic_play_circle_outline_white_48dp);
        }

        @Override
        public void onSoundPlayComplete() {
            Log.e(TAG, "onSoundPlayComplete");
            iv_play.setImageResource(R.drawable.ic_play_circle_outline_white_48dp);
        }

        @Override
        public boolean onError(XmPlayerException exception) {
            Log.e(TAG, "onError " + exception.getMessage());
            iv_play.setImageResource(R.drawable.ic_play_circle_outline_white_48dp);
            return false;
        }

        @Override
        public void onBufferProgress(int position) {
            sb_progress.setSecondaryProgress(position);
        }

        public void onBufferingStart() {
            sb_progress.setEnabled(false);
//            mProgress.setVisibility(View.VISIBLE);
        }

        public void onBufferingStop() {
            sb_progress.setEnabled(true);
//            mProgress.setVisibility(View.GONE);
        }

    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "-----onDestroy");
        if (isximalay == 0) {
            if (mPlayerManager != null) {
                mPlayerManager.removePlayerStatusListener(mPlayerStatusListener);
                mPlayerManager.release();
            }
        } else {
            if (mPlayerOnlineUtil != null) {
                mPlayerOnlineUtil.stop();
                mPlayerOnlineUtil = null;
            }
        }
    }


    public void getTracks(final String id) {
        Map<String, String> map = new HashMap<String, String>();
        map.put(DTransferConstants.ALBUM_ID, id);
        map.put(DTransferConstants.SORT, "asc");
        CommonRequest.getTracks(map, new IDataCallBack<TrackList>() {
            @Override
            public void onSuccess(TrackList trackList) {
                if (mTrackList == null) {
                    mTrackList = trackList;
                } else {
                    // trackList.getTracks().addAll(0, mTrackList.getTracks());
                    mTrackList = trackList;
                }
                String coverUrl = mTrackList.getTracks().get(songPosition).getCoverUrlLarge();
                String title = mTrackList.getTracks().get(songPosition).getTrackTitle();
                String msg = mTrackList.getTracks().get(songPosition).getAnnouncer().getNickname();
                xmlyString = mTrackList.getTracks().get(songPosition).getPlayUrl64();
                if (!TextUtils.isEmpty(title)) {
                    tv_musicname.setText(title);
                }
                if (!TextUtils.isEmpty(msg)) {
                    tv_auther.setText(msg);
                }
                if (!TextUtils.isEmpty(coverUrl)) {
                    displayPic.displayPic(PlayMusicActivity.this, coverUrl, iv_musicimage);
                }
                Log.d(MyApplication.TAG, " getImei----->" + songPosition + " mTrackList= " + mTrackList);
            }

            @Override
            public void onError(int code, String message) {
                Log.d(MyApplication.TAG, " getImei code: " + code + "     message: " + message);
                IToast.makeText(getString(R.string.playmusic_error));
            }
        });
    }

}
