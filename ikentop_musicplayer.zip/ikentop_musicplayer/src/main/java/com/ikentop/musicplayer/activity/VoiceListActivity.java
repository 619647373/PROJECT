package com.ikentop.musicplayer.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cundong.recyclerview.EndlessRecyclerOnScrollListener;
import com.cundong.recyclerview.HeaderAndFooterRecyclerViewAdapter;
import com.cundong.recyclerview.HeaderSpanSizeLookup;
import com.cundong.recyclerview.RecyclerViewUtils;
import com.ikentop.musicplayer.MyApplication;
import com.ikentop.musicplayer.R;
import com.ikentop.musicplayer.bean.voiceListBean;
import com.ikentop.musicplayer.utils.RecyclerViewStateUtils;
import com.ikentop.musicplayer.weight.LoadingFooter;
import com.ikentop.musicplayer.weight.SampleHeader;
import com.ximalaya.ting.android.opensdk.constants.DTransferConstants;
import com.ximalaya.ting.android.opensdk.datatrasfer.CommonRequest;
import com.ximalaya.ting.android.opensdk.datatrasfer.IDataCallBack;
import com.ximalaya.ting.android.opensdk.model.track.TrackList;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by lwj on 2017/12/6.
 */

public class VoiceListActivity extends BaseActivity {
    private String album_id;
    private String nametitle;

    @BindView(R.id.voicelist)
    public RecyclerView mRecyclerView;
    /**
     * 页数
     */
    private int PAGE = 1;

    /**
     * 每一页展示多少条数据
     */
    private static final int REQUEST_COUNT = 10;


    //是否首次加载数据
    private boolean firstLoad;
    //加载接口数据
    private TrackList listresult = new TrackList();

    private ArrayList<voiceListBean> dataList = new ArrayList<>();


    private VoiceListActivity.DataAdapter mDataAdapter = null;

    private VoiceListActivity.PreviewHandler mHandler = new VoiceListActivity.PreviewHandler(VoiceListActivity.this);
    private HeaderAndFooterRecyclerViewAdapter mHeaderAndFooterRecyclerViewAdapter = null;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.voicelist);
        ButterKnife.bind(this);
        firstLoad = true;
        getExra();
        GetVoiceList(PAGE++);

    }

    private void getExra() {
        Intent intent = getIntent();
        album_id = intent.getStringExtra("id");
        nametitle = intent.getStringExtra("title");

    }

    public void GetVoiceList(final int PAGE) {

        Map<String, String> map = new HashMap<String, String>();
        map.put(DTransferConstants.ALBUM_ID, album_id);
        map.put(DTransferConstants.SORT, "asc");
        map.put(DTransferConstants.PAGE, PAGE + "");
        Log.d(MyApplication.TAG," album_id= "+album_id);
        CommonRequest.getTracks(map, new IDataCallBack<TrackList>() {
            @Override
            public void onSuccess(@Nullable TrackList trackList) {
                Log.d(MyApplication.TAG, " PAGE=" + PAGE + "" + trackList.getTracks());
                listresult = trackList;
                if (firstLoad) {
                    firstLoad = false;
                    initRecycle();
                } else {
                    //没有更多数据
                    if (trackList.getTracks().size() == 0) {
                        RecyclerViewStateUtils.setFooterViewState(VoiceListActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.TheEnd, null);
                        return;
                    }
                    listresult = trackList;
                    dataList.clear();

                    for (int i = 0; i < listresult.getTracks().size(); i++) {
                        dataList.add(new voiceListBean(listresult.getTracks().get(i).getTrackTitle(), listresult.getTracks().get(i).getAnnouncer().getNickname(), listresult.getTracks().get(i).getCoverUrlLarge(), listresult.getTracks().get(i).getDataId() + ""));
                    }
                    mHandler.sendEmptyMessage(-1);
                }
            }

            @Override
            public void onError(int i, String s) {
                mHandler.sendEmptyMessage(-3);
            }
        });

    }



    private void initRecycle() {
        //init data
        mDataAdapter = new VoiceListActivity.DataAdapter(this);

        for (int i = 0; i < listresult.getTracks().size(); i++) {
            dataList.add(new voiceListBean(listresult.getTracks().get(i).getTrackTitle(), listresult.getTracks().get(i).getAnnouncer().getNickname(), listresult.getTracks().get(i).getCoverUrlLarge(), listresult.getTracks().get(i).getDataId() + ""));
        }
        mDataAdapter.addAll(dataList);

        mHeaderAndFooterRecyclerViewAdapter = new HeaderAndFooterRecyclerViewAdapter(mDataAdapter);
        mRecyclerView.setAdapter(mHeaderAndFooterRecyclerViewAdapter);

        //setLayoutManager
        GridLayoutManager manager = new GridLayoutManager(this, 1);
        manager.setSpanSizeLookup(new HeaderSpanSizeLookup((HeaderAndFooterRecyclerViewAdapter) mRecyclerView.getAdapter(), manager.getSpanCount()));
        mRecyclerView.setLayoutManager(manager);

        RecyclerViewUtils.setHeaderView(mRecyclerView, new SampleHeader(this, nametitle));

        mRecyclerView.addOnScrollListener(mOnScrollListener);
    }


    private void notifyDataSetChanged() {
        mHeaderAndFooterRecyclerViewAdapter.notifyDataSetChanged();
    }

    private void addItems(ArrayList<voiceListBean> list) {
        mDataAdapter.addAll(list);
    }

    private EndlessRecyclerOnScrollListener mOnScrollListener = new EndlessRecyclerOnScrollListener() {

        @Override
        public void onLoadNextPage(View view) {
            super.onLoadNextPage(view);

            LoadingFooter.State state = RecyclerViewStateUtils.getFooterViewState(mRecyclerView);
            if (state == LoadingFooter.State.Loading) {
                Log.d("@Cundong", "the state is Loading, just wait..");
                return;
            }

            RecyclerViewStateUtils.setFooterViewState(VoiceListActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.Loading, null);
            requestData();
        }
    };

    private class PreviewHandler extends Handler {

        private WeakReference<VoiceListActivity> ref;

        PreviewHandler(VoiceListActivity activity) {
            ref = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            VoiceListActivity activity = ref.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }

            switch (msg.what) {
                case -1:
                    activity.addItems(dataList);
                    RecyclerViewStateUtils.setFooterViewState(activity.mRecyclerView, LoadingFooter.State.Normal);
                    break;
                case -2:
                    activity.notifyDataSetChanged();
                    break;
                case -3:
                    RecyclerViewStateUtils.setFooterViewState(activity, activity.mRecyclerView, REQUEST_COUNT, LoadingFooter.State.NetWorkError, activity.mFooterClick);
                    break;
            }
        }
    }

    private View.OnClickListener mFooterClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            RecyclerViewStateUtils.setFooterViewState(VoiceListActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.Loading, null);
            requestData();
        }
    };


    private void requestData() {
        try {
            GetVoiceList(PAGE++);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class DataAdapter extends RecyclerView.Adapter {

        private LayoutInflater mLayoutInflater;
        private ArrayList<voiceListBean> mDataList = new ArrayList<>();

        public DataAdapter(Context context) {
            mLayoutInflater = LayoutInflater.from(context);
        }

        private void addAll(ArrayList<voiceListBean> list) {
            int lastIndex = this.mDataList.size();
            if (this.mDataList.addAll(list)) {
                notifyItemRangeInserted(lastIndex, list.size());
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new VoiceListActivity.DataAdapter.ViewHolder(mLayoutInflater.inflate(R.layout.voicelist_item, parent, false));
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {


            VoiceListActivity.DataAdapter.ViewHolder viewHolder = (VoiceListActivity.DataAdapter.ViewHolder) holder;
            viewHolder.title.setText(mDataList.get(position).getTitle());
            viewHolder.tag.setText(mDataList.get(position).getTag());
            Glide
                    .with(getApplicationContext())
                    .load(mDataList.get(position).getImg())
                    .into(viewHolder.img);

            viewHolder.lin1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.putExtra("id",album_id );// mDataList.get(position).getId()
                    intent.putExtra("songPosition",position+"");
                    intent.setClass(VoiceListActivity.this, PlayMusicActivity.class);
                    startActivity(intent);

                }
            });

        }

        @Override
        public int getItemCount() {
            return mDataList.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {

            private ImageView img;
            private TextView title;
            private TextView tag;
            private LinearLayout lin1;

            public ViewHolder(View itemView) {
                super(itemView);
                img = (ImageView) itemView.findViewById(R.id.info_text);
                title = (TextView) itemView.findViewById(R.id.title);
                tag = (TextView) itemView.findViewById(R.id.tag);
                lin1 = (LinearLayout) itemView.findViewById(R.id.lin1);

            }
        }
    }


}
