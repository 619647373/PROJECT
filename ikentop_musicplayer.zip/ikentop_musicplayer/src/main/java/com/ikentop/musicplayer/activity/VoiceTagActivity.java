package com.ikentop.musicplayer.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.cundong.recyclerview.EndlessRecyclerOnScrollListener;
import com.cundong.recyclerview.HeaderAndFooterRecyclerViewAdapter;
import com.cundong.recyclerview.HeaderSpanSizeLookup;
import com.cundong.recyclerview.RecyclerViewUtils;
import com.ikentop.musicplayer.MyApplication;
import com.ikentop.musicplayer.R;
import com.ikentop.musicplayer.bean.voiceTagBean;
import com.ikentop.musicplayer.utils.RecyclerViewStateUtils;
import com.ikentop.musicplayer.weight.LoadingFooter;
import com.ikentop.musicplayer.weight.SampleHeader;
import com.ximalaya.ting.android.opensdk.constants.DTransferConstants;
import com.ximalaya.ting.android.opensdk.datatrasfer.CommonRequest;
import com.ximalaya.ting.android.opensdk.datatrasfer.IDataCallBack;
import com.ximalaya.ting.android.opensdk.model.album.AlbumList;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by lwj on 2017/12/6.
 */

public class VoiceTagActivity extends BaseActivity {
    private String categoryId;
    private String nametitle;

    @BindView(R.id.listtag)
    public RecyclerView mRecyclerView;
    /**
     * 页数
     */
    private int PAGE = 1;

    /**
     * 每一页展示多少条数据
     */
    private static final int REQUEST_COUNT = 10;


    //是否首次加载数据
    private boolean firstLoad;
    //加载接口数据
    private AlbumList listresult = new AlbumList();

    private ArrayList<voiceTagBean> dataList = new ArrayList<>();
    ;

    private VoiceTagActivity.DataAdapter mDataAdapter = null;

    private VoiceTagActivity.PreviewHandler mHandler = new VoiceTagActivity.PreviewHandler(VoiceTagActivity.this);
    private HeaderAndFooterRecyclerViewAdapter mHeaderAndFooterRecyclerViewAdapter = null;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.voicetag);
        ButterKnife.bind(this);
        firstLoad = true;
        getExra();
        GetVoiceTag(PAGE++);

    }

    private void getExra() {
        Intent intent = getIntent();
        categoryId = intent.getStringExtra("id");
        nametitle = intent.getStringExtra("title");

    }

    public void GetVoiceTag(final int PAGE) {

        Map<String, String> map = new HashMap<String, String>();
        map.put(DTransferConstants.CATEGORY_ID, categoryId);
        map.put(DTransferConstants.CALC_DIMENSION, "1");
        map.put(DTransferConstants.PAGE, PAGE + "");
        CommonRequest.getAlbumList(map, new IDataCallBack<AlbumList>() {
            @Override
            public void onSuccess(@Nullable AlbumList albumList) {
                Log.d(MyApplication.TAG, " PAGE=" + PAGE + "" + albumList.getAlbums());
                listresult = albumList;
                if (firstLoad) {
                    firstLoad = false;
                    initRecycle();
                } else {
                    //没有更多数据
                    if (albumList.getAlbums().size() == 0) {
                        RecyclerViewStateUtils.setFooterViewState(VoiceTagActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.TheEnd, null);
                        return;
                    }

                    listresult = albumList;
                    dataList.clear();

                    for (int i = 0; i < listresult.getAlbums().size(); i++) {
                        dataList.add(new voiceTagBean(listresult.getAlbums().get(i).getAlbumTitle(), listresult.getAlbums().get(i).getAnnouncer().getNickname(), listresult.getAlbums().get(i).getCoverUrlLarge(), listresult.getAlbums().get(i).getId() + ""));
                    }
                    mHandler.sendEmptyMessage(-1);
                }

            }

            @Override
            public void onError(int i, String s) {
                mHandler.sendEmptyMessage(-3);
            }
        });

    }

    private void initRecycle() {
        //init data
        mDataAdapter = new VoiceTagActivity.DataAdapter(this);

        for (int i = 0; i < listresult.getAlbums().size(); i++) {
            dataList.add(new voiceTagBean(listresult.getAlbums().get(i).getAlbumTitle(), listresult.getAlbums().get(i).getAnnouncer().getNickname(), listresult.getAlbums().get(i).getCoverUrlLarge(), listresult.getAlbums().get(i).getId() + ""));
        }
        mDataAdapter.addAll(dataList);

        mHeaderAndFooterRecyclerViewAdapter = new HeaderAndFooterRecyclerViewAdapter(mDataAdapter);
        mRecyclerView.setAdapter(mHeaderAndFooterRecyclerViewAdapter);

        //setLayoutManager
        GridLayoutManager manager = new GridLayoutManager(this, 1);
        manager.setSpanSizeLookup(new HeaderSpanSizeLookup((HeaderAndFooterRecyclerViewAdapter) mRecyclerView.getAdapter(), manager.getSpanCount()));
        mRecyclerView.setLayoutManager(manager);

        RecyclerViewUtils.setHeaderView(mRecyclerView, new SampleHeader(this,nametitle));

        mRecyclerView.addOnScrollListener(mOnScrollListener);
    }


    private void notifyDataSetChanged() {
        mHeaderAndFooterRecyclerViewAdapter.notifyDataSetChanged();
    }

    private void addItems(ArrayList<voiceTagBean> list) {
        mDataAdapter.addAll(list);
    }

    private EndlessRecyclerOnScrollListener mOnScrollListener = new EndlessRecyclerOnScrollListener() {

        @Override
        public void onLoadNextPage(View view) {
            super.onLoadNextPage(view);

            LoadingFooter.State state = RecyclerViewStateUtils.getFooterViewState(mRecyclerView);
            if (state == LoadingFooter.State.Loading) {
                Log.d("@Cundong", "the state is Loading, just wait..");
                return;
            }

            RecyclerViewStateUtils.setFooterViewState(VoiceTagActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.Loading, null);
            requestData();

//            if (mCurrentCounter < TOTAL_COUNTER) {
//                // loading more
//                RecyclerViewStateUtils.setFooterViewState(VoiceTagActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.Loading, null);
//                requestData();
//            } else {
//                //the end
//                RecyclerViewStateUtils.setFooterViewState(VoiceTagActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.TheEnd, null);
//            }
        }
    };

    private class PreviewHandler extends Handler {

        private WeakReference<VoiceTagActivity> ref;

        PreviewHandler(VoiceTagActivity activity) {
            ref = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            VoiceTagActivity activity = ref.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }

            switch (msg.what) {
                case -1:
                    activity.addItems(dataList);
                    RecyclerViewStateUtils.setFooterViewState(activity.mRecyclerView, LoadingFooter.State.Normal);
                    break;
                case -2:
                    activity.notifyDataSetChanged();
                    break;
                case -3:
                    RecyclerViewStateUtils.setFooterViewState(activity, activity.mRecyclerView, REQUEST_COUNT, LoadingFooter.State.NetWorkError, activity.mFooterClick);
                    break;
            }
        }
    }

    private View.OnClickListener mFooterClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            RecyclerViewStateUtils.setFooterViewState(VoiceTagActivity.this, mRecyclerView, REQUEST_COUNT, LoadingFooter.State.Loading, null);
            requestData();
        }
    };

    /**
     * 模拟请求网络
     */
    private void requestData() {

        new Thread() {

            @Override
            public void run() {
                super.run();

                try {
                    GetVoiceTag(PAGE++);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }.start();
    }

    private class DataAdapter extends RecyclerView.Adapter {

        private LayoutInflater mLayoutInflater;
        private ArrayList<voiceTagBean> mDataList = new ArrayList<>();

        public DataAdapter(Context context) {
            mLayoutInflater = LayoutInflater.from(context);
        }

        private void addAll(ArrayList<voiceTagBean> list) {
            int lastIndex = this.mDataList.size();
            if (this.mDataList.addAll(list)) {
                notifyItemRangeInserted(lastIndex, list.size());
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new VoiceTagActivity.DataAdapter.ViewHolder(mLayoutInflater.inflate(R.layout.voicetag_item, parent, false));
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {


            VoiceTagActivity.DataAdapter.ViewHolder viewHolder = (VoiceTagActivity.DataAdapter.ViewHolder) holder;
            viewHolder.title.setText(mDataList.get(position).getTitle());
            viewHolder.tag.setText(mDataList.get(position).getTag());
            Glide
                    .with(getApplicationContext())
                    .load(mDataList.get(position).getImg())
                    .into(viewHolder.img);

            viewHolder.lin1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent();
                    intent.putExtra("id", mDataList.get(position).getId());
                    intent.putExtra("title", mDataList.get(position).getTitle());
                    intent.setClass(VoiceTagActivity.this, VoiceListActivity.class);
                    startActivity(intent);

                }
            });

        }

        @Override
        public int getItemCount() {
            return mDataList.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {

            private ImageView img;
            private TextView title;
            private TextView tag;
            private LinearLayout lin1;

            public ViewHolder(View itemView) {
                super(itemView);
                img = (ImageView) itemView.findViewById(R.id.info_text);
                title = (TextView) itemView.findViewById(R.id.title);
                tag = (TextView) itemView.findViewById(R.id.tag);
                lin1 = (LinearLayout) itemView.findViewById(R.id.lin1);

            }
        }
    }


}
