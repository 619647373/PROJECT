package com.ikentop.musicplayer.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lwj on 2017/12/7.
 */

public class Model_ZiliaokuThree {



    private AudioinfosBean audioinfos;
    /**
     * audioinfos : {"cats":[],"contents":[{"audio_price":0,"name":"洋娃娃和小熊跳舞","play_url":"http://cdn.open.idaddy.cn/apsmp3/50ed/loobot0000000001/201610160000/0/YS82L2w4bnZoM3B6LmF1ZGlv.mp3","price":0,"audio_name":"洋娃娃和小熊跳舞","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/50ed/loobot0000000001/201610160000/0/YS82L2w4bnZoM3B6LmF1ZGlv.mp3","md5_file":"3b5b0cc9c572b969260d402e83889a28","chapter_count":0,"is_multichapter":0,"md5":"3b5b0cc9c572b969260d402e83889a28","id":"ADwGZAU_","audio_id":"ADwGZAU_","icon":"http://img.idaddy.cn/b/6/l8nvh3pz.jpg"},{"audio_price":0,"name":"铃儿响叮当","play_url":"http://cdn.open.idaddy.cn/apsmp3/11f4/loobot0000000001/201610160000/0/YTY0LzgvdTg0dDY2MG4uYXVkaW8=.mp3","price":0,"audio_name":"铃儿响叮当","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/11f4/loobot0000000001/201610160000/0/YTY0LzgvdTg0dDY2MG4uYXVkaW8=.mp3","md5_file":"aeb0973dddf85d2365fd82e1cbc6caca","chapter_count":0,"is_multichapter":0,"md5":"aeb0973dddf85d2365fd82e1cbc6caca","id":"ADwGYQUx","audio_id":"ADwGYQUx","icon":"http://img.idaddy.cn//b/8/myrmq5w9.jpg"},{"audio_price":0,"name":"鲁冰花","play_url":"http://cdn.open.idaddy.cn/apsmp3/3c23/loobot0000000001/201610160000/0/YTY0LzkvZWpvbjBlZTcuYXVkaW8=.mp3","price":0,"audio_name":"鲁冰花","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/3c23/loobot0000000001/201610160000/0/YTY0LzkvZWpvbjBlZTcuYXVkaW8=.mp3","md5_file":"dba6efbaf034ef75bc18e30680939e69","chapter_count":0,"is_multichapter":0,"md5":"dba6efbaf034ef75bc18e30680939e69","id":"ADwGYQUw","audio_id":"ADwGYQUw","icon":"http://img.idaddy.cn/b/9/4ef7he2k.jpg"},{"audio_price":0,"name":"让我们荡起双桨","play_url":"http://cdn.open.idaddy.cn/apsmp3/a224/loobot0000000001/201610160000/0/YTY0LzAvNnNwdm16d2wuYXVkaW8=.mp3","price":0,"audio_name":"让我们荡起双桨","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/a224/loobot0000000001/201610160000/0/YTY0LzAvNnNwdm16d2wuYXVkaW8=.mp3","md5_file":"e1738340572dd2eb8d7dd8a15336cfd1","chapter_count":0,"is_multichapter":0,"md5":"e1738340572dd2eb8d7dd8a15336cfd1","id":"ADwGZgU5","audio_id":"ADwGZgU5","icon":"http://img.idaddy.cn/b/0/na7d38hm.jpg"},{"audio_price":0,"name":"小燕子","play_url":"http://cdn.open.idaddy.cn/apsmp3/a294/loobot0000000001/201610160000/0/YS82LzN6YXg1bzVtLmF1ZGlv.mp3","price":0,"audio_name":"小燕子","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/a294/loobot0000000001/201610160000/0/YS82LzN6YXg1bzVtLmF1ZGlv.mp3","md5_file":"2a3fceb2c945e8ceeb63b63bfd168d40","chapter_count":0,"is_multichapter":0,"md5":"2a3fceb2c945e8ceeb63b63bfd168d40","id":"ADwGZgU_","audio_id":"ADwGZgU_","icon":"http://img.idaddy.cn//b/6/3zax5o5m.jpg"},{"audio_price":0,"name":"蓝精灵之歌","play_url":"http://cdn.open.idaddy.cn/apsmp3/7566/loobot0000000001/201610160000/0/YS8zL3I1NmI5ZmJxLmF1ZGlv.mp3","price":0,"audio_name":"蓝精灵之歌","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/7566/loobot0000000001/201610160000/0/YS8zL3I1NmI5ZmJxLmF1ZGlv.mp3","md5_file":"2bb54c3552bf536b2b5e69567d024801","chapter_count":0,"is_multichapter":0,"md5":"2bb54c3552bf536b2b5e69567d024801","id":"ADwGZwU6","audio_id":"ADwGZwU6","icon":"http://img.idaddy.cn/b/3/m8h11hkp.jpg"},{"audio_price":0,"name":"小毛驴","play_url":"http://cdn.open.idaddy.cn/apsmp3/8bb4/loobot0000000001/201610160000/0/YTY0LzUvbmN5cmd0ZmkuYXVkaW8=.mp3","price":0,"audio_name":"小毛驴","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/8bb4/loobot0000000001/201610160000/0/YTY0LzUvbmN5cmd0ZmkuYXVkaW8=.mp3","md5_file":"942fe725b3fde36105d2aeda44869fb6","chapter_count":0,"is_multichapter":0,"md5":"942fe725b3fde36105d2aeda44869fb6","id":"ADwGZwU8","audio_id":"ADwGZwU8","icon":"http://img.idaddy.cn//b/5/9s6b3rw2.jpg"},{"audio_price":0,"name":"小螺号","play_url":"http://cdn.open.idaddy.cn/apsmp3/7f55/loobot0000000001/201610160000/0/YTY0LzYvZmVudWYxZDguYXVkaW8=.mp3","price":0,"audio_name":"小螺号","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/7f55/loobot0000000001/201610160000/0/YTY0LzYvZmVudWYxZDguYXVkaW8=.mp3","md5_file":"362c988cc42f5d21cfa78019e5e48f6d","chapter_count":0,"is_multichapter":0,"md5":"362c988cc42f5d21cfa78019e5e48f6d","id":"ADwGZwU_","audio_id":"ADwGZwU_","icon":"http://img.idaddy.cn/b/6/94vlrnx5.jpg"},{"audio_price":0,"name":"数鸭子","play_url":"http://cdn.open.idaddy.cn/apsmp3/2119/loobot0000000001/201610160000/0/YS83L2x2MTNicGd0LmF1ZGlv.mp3","price":0,"audio_name":"数鸭子","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/2119/loobot0000000001/201610160000/0/YS83L2x2MTNicGd0LmF1ZGlv.mp3","md5_file":"a13ba516fa19c1fd74c976f29426e562","chapter_count":0,"is_multichapter":0,"md5":"a13ba516fa19c1fd74c976f29426e562","id":"ADwGZwU-","audio_id":"ADwGZwU-","icon":"http://img.idaddy.cn/b/7/lv13bpgt.jpg"},{"audio_price":0,"name":"蜗牛与黄鹂鸟","play_url":"http://cdn.open.idaddy.cn/apsmp3/4620/loobot0000000001/201610160000/0/YS84L2c4MXhvenU2LmF1ZGlv.mp3","price":0,"audio_name":"蜗牛与黄鹂鸟","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/4620/loobot0000000001/201610160000/0/YS84L2c4MXhvenU2LmF1ZGlv.mp3","md5_file":"acf1b91ba333507f3be589a4fff8159d","chapter_count":0,"is_multichapter":0,"md5":"acf1b91ba333507f3be589a4fff8159d","id":"ADwGZwUx","audio_id":"ADwGZwUx","icon":"http://img.idaddy.cn/b/8/we67dx2x.jpg"},{"audio_price":0,"name":"小兔子乖乖（儿歌版）","play_url":"http://cdn.open.idaddy.cn/apsmp3/c68e/loobot0000000001/201610160000/0/YTY0LzAvaWFobzh3aS5hdWRpbw==.mp3","price":0,"audio_name":"小兔子乖乖（儿歌版）","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/c68e/loobot0000000001/201610160000/0/YTY0LzAvaWFobzh3aS5hdWRpbw==.mp3","md5_file":"8b76683368bd9f32dde43722f8f3280e","chapter_count":0,"is_multichapter":0,"md5":"8b76683368bd9f32dde43722f8f3280e","id":"ADwGZwUw","audio_id":"ADwGZwUw","icon":"http://img.idaddy.cn/b/9/w48etqob.jpg"},{"audio_price":0,"name":"找朋友","play_url":"http://cdn.open.idaddy.cn/apsmp3/3344/loobot0000000001/201610160000/0/YTY0LzMvNnNoOGxsOWwuYXVkaW8=.mp3","price":0,"audio_name":"找朋友","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/3344/loobot0000000001/201610160000/0/YTY0LzMvNnNoOGxsOWwuYXVkaW8=.mp3","md5_file":"7569a2594c13a5e57542fb5e749fd7d3","chapter_count":0,"is_multichapter":0,"md5":"7569a2594c13a5e57542fb5e749fd7d3","id":"ADwGZAU5","audio_id":"ADwGZAU5","icon":"http://img.idaddy.cn/b/0/6sh8ll9l.jpg"},{"audio_price":0,"name":"捉泥鳅","play_url":"http://cdn.open.idaddy.cn/apsmp3/ad79/loobot0000000001/201610160000/0/YTY0LzEvcnJhd3c1eTMuYXVkaW8=.mp3","price":0,"audio_name":"捉泥鳅","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/ad79/loobot0000000001/201610160000/0/YTY0LzEvcnJhd3c1eTMuYXVkaW8=.mp3","md5_file":"0ed1e3b9d4da1e848d604fcfbaf1897b","chapter_count":0,"is_multichapter":0,"md5":"0ed1e3b9d4da1e848d604fcfbaf1897b","id":"ADwGZAU4","audio_id":"ADwGZAU4","icon":"http://img.idaddy.cn//b/1/rraww5y3.jpg"},{"audio_price":0,"name":"泥娃娃","play_url":"http://cdn.open.idaddy.cn/apsmp3/2d89/loobot0000000001/201610160000/0/YTY0LzEvbG03NzV6eXAuYXVkaW8=.mp3","price":0,"audio_name":"泥娃娃","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/2d89/loobot0000000001/201610160000/0/YTY0LzEvbG03NzV6eXAuYXVkaW8=.mp3","md5_file":"798d451c98dfd945e8d29444b8058e0a","chapter_count":0,"is_multichapter":0,"md5":"798d451c98dfd945e8d29444b8058e0a","id":"ADwGZQU4","audio_id":"ADwGZQU4","icon":"http://img.idaddy.cn///b/1/lm775zyp.jpg"},{"audio_price":0,"name":"走在乡间的小路上","play_url":"http://cdn.open.idaddy.cn/apsmp3/c6f0/loobot0000000001/201610160000/0/YS8yL3VzNGI3cm1pLmF1ZGlv.mp3","price":0,"audio_name":"走在乡间的小路上","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/c6f0/loobot0000000001/201610160000/0/YS8yL3VzNGI3cm1pLmF1ZGlv.mp3","md5_file":"1397ecbde204e89b59739ebf62eca8dd","chapter_count":0,"is_multichapter":0,"md5":"1397ecbde204e89b59739ebf62eca8dd","id":"ADwGZQU7","audio_id":"ADwGZQU7","icon":"http://img.idaddy.cn/b/2/us4b7rmi.jpg"},{"audio_price":0,"name":"娃哈哈","play_url":"http://cdn.open.idaddy.cn/apsmp3/06d9/loobot0000000001/201610160000/0/YTY0LzQvZ3kzY202eHIuYXVkaW8=.mp3","price":0,"audio_name":"娃哈哈","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/06d9/loobot0000000001/201610160000/0/YTY0LzQvZ3kzY202eHIuYXVkaW8=.mp3","md5_file":"4f27f42951bc48f2143a1fb6448e47ce","chapter_count":0,"is_multichapter":0,"md5":"4f27f42951bc48f2143a1fb6448e47ce","id":"ADwGZQU9","audio_id":"ADwGZQU9","icon":"http://img.idaddy.cn/b/4/gy3cm6xr.jpg"},{"audio_price":0,"name":"拔萝卜","play_url":"http://cdn.open.idaddy.cn/apsmp3/1925/loobot0000000001/201610160000/0/YS83L2piMjZucjM2LmF1ZGlv.mp3","price":0,"audio_name":"拔萝卜","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/1925/loobot0000000001/201610160000/0/YS83L2piMjZucjM2LmF1ZGlv.mp3","md5_file":"87b8ab46c634893e243f8a82f5927ef1","chapter_count":0,"is_multichapter":0,"md5":"87b8ab46c634893e243f8a82f5927ef1","id":"ADwGZQU-","audio_id":"ADwGZQU-","icon":"http://img.idaddy.cn/b/7/jb26nr36.jpg"},{"audio_price":0,"name":"采蘑菇的小姑娘","play_url":"http://cdn.open.idaddy.cn/apsmp3/95ce/loobot0000000001/201610160000/0/YTY0LzgvMjA5eGd5ZTMuYXVkaW8=.mp3","price":0,"audio_name":"采蘑菇的小姑娘","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/95ce/loobot0000000001/201610160000/0/YTY0LzgvMjA5eGd5ZTMuYXVkaW8=.mp3","md5_file":"824fd5d83e72fc61bc8c4b058bd69c8b","chapter_count":0,"is_multichapter":0,"md5":"824fd5d83e72fc61bc8c4b058bd69c8b","id":"ADwGZQUx","audio_id":"ADwGZQUx","icon":"http://img.idaddy.cn//b/8/209xgye3.jpg"},{"audio_price":0,"name":"外婆的澎湖湾","play_url":"http://cdn.open.idaddy.cn/apsmp3/d547/loobot0000000001/201610160000/0/YTY0LzEvNmkxbzF2MS5hdWRpbw==.mp3","price":0,"audio_name":"外婆的澎湖湾","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/d547/loobot0000000001/201610160000/0/YTY0LzEvNmkxbzF2MS5hdWRpbw==.mp3","md5_file":"2a634f9936d074e777860a7af4c51e9f","chapter_count":0,"is_multichapter":0,"md5":"2a634f9936d074e777860a7af4c51e9f","id":"ADwGagU4","audio_id":"ADwGagU4","icon":"http://img.idaddy.cn//b/1/6i1o1v1.jpg"},{"audio_price":0,"name":"我爱洗澡","play_url":"http://cdn.open.idaddy.cn/apsmp3/c6a9/loobot0000000001/201610160000/0/YTY0LzIvM2dvNHc0MG4uYXVkaW8=.mp3","price":0,"audio_name":"我爱洗澡","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/c6a9/loobot0000000001/201610160000/0/YTY0LzIvM2dvNHc0MG4uYXVkaW8=.mp3","md5_file":"7d90127faaf60a1c01eb4888e4eb0f43","chapter_count":0,"is_multichapter":0,"md5":"7d90127faaf60a1c01eb4888e4eb0f43","id":"ADwGagU7","audio_id":"ADwGagU7","icon":"http://img.idaddy.cn/b/2/d3bcsajo.jpg"},{"audio_price":0,"name":"打电话","play_url":"http://cdn.open.idaddy.cn/apsmp3/e074/loobot0000000001/201610160000/0/YTY0LzcvYnBhY2o1MWcuYXVkaW8=.mp3","price":0,"audio_name":"打电话","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/e074/loobot0000000001/201610160000/0/YTY0LzcvYnBhY2o1MWcuYXVkaW8=.mp3","md5_file":"3f6a98f1b4385022387117429c7927fa","chapter_count":0,"is_multichapter":0,"md5":"3f6a98f1b4385022387117429c7927fa","id":"ADwGagU-","audio_id":"ADwGagU-","icon":"http://img.idaddy.cn/b/7/bpacj51g.jpg"},{"audio_price":0,"name":"幸福拍手歌","play_url":"http://cdn.open.idaddy.cn/apsmp3/7ea6/loobot0000000001/201610160000/0/YTY0LzEvajc5dTVjYWsuYXVkaW8=.mp3","price":0,"audio_name":"幸福拍手歌","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/7ea6/loobot0000000001/201610160000/0/YTY0LzEvajc5dTVjYWsuYXVkaW8=.mp3","md5_file":"2b593a5dd455e193ef92c290be0d0a8c","chapter_count":0,"is_multichapter":0,"md5":"2b593a5dd455e193ef92c290be0d0a8c","id":"ADwGawU4","audio_id":"ADwGawU4","icon":"http://img.idaddy.cn//b/1/j79u5cak.jpg"},{"audio_price":0,"name":"一分钱","play_url":"http://cdn.open.idaddy.cn/apsmp3/4c66/loobot0000000001/201610160000/0/YTY0LzIvZGNlYXl5djkuYXVkaW8=.mp3","price":0,"audio_name":"一分钱","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/4c66/loobot0000000001/201610160000/0/YTY0LzIvZGNlYXl5djkuYXVkaW8=.mp3","md5_file":"50fbe9aaa0c19729467d85adb7fe2a0d","chapter_count":0,"is_multichapter":0,"md5":"50fbe9aaa0c19729467d85adb7fe2a0d","id":"ADwGawU7","audio_id":"ADwGawU7","icon":"http://img.idaddy.cn///b/2/6a2m0twc.jpg"},{"audio_price":0,"name":"一只哈巴狗","play_url":"http://cdn.open.idaddy.cn/apsmp3/5399/loobot0000000001/201610160000/0/YTY0LzkvZ293M2NiejMuYXVkaW8=.mp3","price":0,"audio_name":"一只哈巴狗","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/5399/loobot0000000001/201610160000/0/YTY0LzkvZ293M2NiejMuYXVkaW8=.mp3","md5_file":"cd5bee243a27dd943663f73f196994f5","chapter_count":0,"is_multichapter":0,"md5":"cd5bee243a27dd943663f73f196994f5","id":"ADwGawUw","audio_id":"ADwGawUw","icon":"http://img.idaddy.cn/b/9/gow3cbz3.jpg"},{"audio_price":0,"name":"我是一个粉刷匠","play_url":"http://cdn.open.idaddy.cn/apsmp3/fced/loobot0000000001/201610160000/0/YTY0LzAvcDRyajFpcG0uYXVkaW8=.mp3","price":0,"audio_name":"我是一个粉刷匠","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/fced/loobot0000000001/201610160000/0/YTY0LzAvcDRyajFpcG0uYXVkaW8=.mp3","md5_file":"6c232fcada7d4be2fb02f2f531cdf58a","chapter_count":0,"is_multichapter":0,"md5":"6c232fcada7d4be2fb02f2f531cdf58a","id":"AD0GYgU5","audio_id":"AD0GYgU5","icon":"http://img.idaddy.cn//b/0/p4rj1ipm.jpg"},{"audio_price":0,"name":"花仙子之歌","play_url":"http://cdn.open.idaddy.cn/apsmp3/c6d4/loobot0000000001/201610160000/0/YTY0LzYvbTIwcGl0MDkuYXVkaW8=.mp3","price":0,"audio_name":"花仙子之歌","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/c6d4/loobot0000000001/201610160000/0/YTY0LzYvbTIwcGl0MDkuYXVkaW8=.mp3","md5_file":"46525d5a1bd88c7116f680b3660ed68a","chapter_count":0,"is_multichapter":0,"md5":"46525d5a1bd88c7116f680b3660ed68a","id":"AD0GYgU_","audio_id":"AD0GYgU_","icon":"http://img.idaddy.cn//b/6/j7g4ky0k.jpg"},{"audio_price":0,"name":"我是小蜜蜂","play_url":"http://cdn.open.idaddy.cn/apsmp3/b7dd/loobot0000000001/201610160000/0/YS8wL3Q3NTUxem02LmF1ZGlv.mp3","price":0,"audio_name":"我是小蜜蜂","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/b7dd/loobot0000000001/201610160000/0/YS8wL3Q3NTUxem02LmF1ZGlv.mp3","md5_file":"267d2d99688731ae9af6cb538ef65b93","chapter_count":0,"is_multichapter":0,"md5":"267d2d99688731ae9af6cb538ef65b93","id":"AD0GYgU-","audio_id":"AD0GYgU-","icon":"http://img.idaddy.cn/b/7/t7551zm6.jpg"},{"audio_price":0,"name":"白龙马","play_url":"http://cdn.open.idaddy.cn/apsmp3/5384/loobot0000000001/201610160000/0/YTY0LzAvZnNoNGRobHEuYXVkaW8=.mp3","price":0,"audio_name":"白龙马","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/5384/loobot0000000001/201610160000/0/YTY0LzAvZnNoNGRobHEuYXVkaW8=.mp3","md5_file":"612f1520fa07ab32bdb69494e46c5fb7","chapter_count":0,"is_multichapter":0,"md5":"612f1520fa07ab32bdb69494e46c5fb7","id":"AD0GYwU6","audio_id":"AD0GYwU6","icon":"http://img.idaddy.cn/b/3/wumbfdbf.jpg"},{"audio_price":0,"name":"小老鼠上灯台","play_url":"http://cdn.open.idaddy.cn/apsmp3/a663/loobot0000000001/201610160000/0/YTY0LzQvNWJ0ODVwZXouYXVkaW8=.mp3","price":0,"audio_name":"小老鼠上灯台","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/a663/loobot0000000001/201610160000/0/YTY0LzQvNWJ0ODVwZXouYXVkaW8=.mp3","md5_file":"fb8893e72f41112c500ed9bf9799179f","chapter_count":0,"is_multichapter":0,"md5":"fb8893e72f41112c500ed9bf9799179f","id":"AD0GYwU9","audio_id":"AD0GYwU9","icon":"http://img.idaddy.cn//b/4/5bt85pez.jpg"},{"audio_price":0,"name":"十二生肖","play_url":"http://cdn.open.idaddy.cn/apsmp3/126c/loobot0000000001/201610160000/0/YTY0LzUvb3VnbDMxenMuYXVkaW8=.mp3","price":0,"audio_name":"十二生肖","has_chapter":0,"audio_filename":"http://cdn.open.idaddy.cn/apsmp3/126c/loobot0000000001/201610160000/0/YTY0LzUvb3VnbDMxenMuYXVkaW8=.mp3","md5_file":"16d9b6f04986c7e41af96b88c747d1da","chapter_count":0,"is_multichapter":0,"md5":"16d9b6f04986c7e41af96b88c747d1da","id":"AD0GYwU8","audio_id":"AD0GYwU8","icon":"http://img.idaddy.cn/b/5/ougl31zs.jpg"}]}
     * retcode : 0
     */

    private int retcode;

    public AudioinfosBean getAudioinfos() {
        return audioinfos;
    }

    public void setAudioinfos(AudioinfosBean audioinfos) {
        this.audioinfos = audioinfos;
    }

    public int getRetcode() {
        return retcode;
    }

    public void setRetcode(int retcode) {
        this.retcode = retcode;
    }

    public static class AudioinfosBean {
        private List<?> cats;
        /**
         * audio_price : 0
         * name : 洋娃娃和小熊跳舞
         * play_url : http://cdn.open.idaddy.cn/apsmp3/50ed/loobot0000000001/201610160000/0/YS82L2w4bnZoM3B6LmF1ZGlv.mp3
         * price : 0
         * audio_name : 洋娃娃和小熊跳舞
         * has_chapter : 0
         * audio_filename : http://cdn.open.idaddy.cn/apsmp3/50ed/loobot0000000001/201610160000/0/YS82L2w4bnZoM3B6LmF1ZGlv.mp3
         * md5_file : 3b5b0cc9c572b969260d402e83889a28
         * chapter_count : 0
         * is_multichapter : 0
         * md5 : 3b5b0cc9c572b969260d402e83889a28
         * id : ADwGZAU_
         * audio_id : ADwGZAU_
         * icon : http://img.idaddy.cn/b/6/l8nvh3pz.jpg
         */

        private List<ContentsBean> contents;

        public List<?> getCats() {
            return cats;
        }

        public void setCats(List<?> cats) {
            this.cats = cats;
        }

        public List<ContentsBean> getContents() {
            return contents;
        }

        public void setContents(List<ContentsBean> contents) {
            this.contents = contents;
        }

        public static class ContentsBean implements Serializable {
            private int audio_price;
            private String name;
            private String play_url;
            private int price;
            private String audio_name;
            private int has_chapter;
            private String audio_filename;
            private String md5_file;
            private int chapter_count;
            private int is_multichapter;
            private String md5;
            private String id;
            private String audio_id;
            private String icon;

            public int getAudio_price() {
                return audio_price;
            }

            public void setAudio_price(int audio_price) {
                this.audio_price = audio_price;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPlay_url() {
                return play_url;
            }

            public void setPlay_url(String play_url) {
                this.play_url = play_url;
            }

            public int getPrice() {
                return price;
            }

            public void setPrice(int price) {
                this.price = price;
            }

            public String getAudio_name() {
                return audio_name;
            }

            public void setAudio_name(String audio_name) {
                this.audio_name = audio_name;
            }

            public int getHas_chapter() {
                return has_chapter;
            }

            public void setHas_chapter(int has_chapter) {
                this.has_chapter = has_chapter;
            }

            public String getAudio_filename() {
                return audio_filename;
            }

            public void setAudio_filename(String audio_filename) {
                this.audio_filename = audio_filename;
            }

            public String getMd5_file() {
                return md5_file;
            }

            public void setMd5_file(String md5_file) {
                this.md5_file = md5_file;
            }

            public int getChapter_count() {
                return chapter_count;
            }

            public void setChapter_count(int chapter_count) {
                this.chapter_count = chapter_count;
            }

            public int getIs_multichapter() {
                return is_multichapter;
            }

            public void setIs_multichapter(int is_multichapter) {
                this.is_multichapter = is_multichapter;
            }

            public String getMd5() {
                return md5;
            }

            public void setMd5(String md5) {
                this.md5 = md5;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getAudio_id() {
                return audio_id;
            }

            public void setAudio_id(String audio_id) {
                this.audio_id = audio_id;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }
        }
    }
}
