package com.ikentop.musicplayer.bean;

/**
 * Created by lwj on 2017/12/6.
 */

public class typeBean {
    private String name;
    private String img;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    private String category_id;

    public typeBean(String name,String img,String category_id){
        this.name=name;
        this.img=img;
        this.category_id=category_id;

    }

}
