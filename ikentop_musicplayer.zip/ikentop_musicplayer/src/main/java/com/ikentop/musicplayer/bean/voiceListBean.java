package com.ikentop.musicplayer.bean;

/**
 * Created by lwj on 2017/12/7.
 */

public class voiceListBean {

    private String title;
    private String img;
    private String tag;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String id;

    public voiceListBean(String title, String tag, String img, String id){
        this.title=title;
        this.tag=tag;
        this.img=img;
        this.id=id;

    }
}
