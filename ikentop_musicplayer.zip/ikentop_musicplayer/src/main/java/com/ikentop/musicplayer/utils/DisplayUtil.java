package com.ikentop.musicplayer.utils;

import android.content.Context;
import android.widget.ImageView;

import com.ikentop.musicplayer.MyApplication;
import com.squareup.picasso.Picasso;


public class DisplayUtil {
    /**
     * @param context   上下文
     * @param url       图片url
     * @param imageView 图片view
     */
    public static void displayPic(Context context, String url, ImageView imageView) {
        if (url != null) {
            boolean isShowpicNoWifi = MyApplication.getInstance().getBooleanValue("isShowpicNoWifi", true);
            if (isShowpicNoWifi) {//任何网络环境都允许访问图片
                Picasso.with(context).load(EncodingUtil.urlEncode(url)).into(imageView);
            } else {//只有wifi环境能允许访问图片
                if (NetUtil.isWifiAvailable(context)) {
                    Picasso.with(context).load(EncodingUtil.urlEncode(url)).into(imageView);
                }
            }
        }
    }


    /**
     * @param context        上下文
     * @param url            图片url
     * @param imageView      图片view
     * @param displayOptions 图片占位图
     */
    public static void displayPic(Context context, String url, ImageView imageView, DisplayOptions displayOptions) {
        if (url != null && displayOptions != null) {
            boolean isShowpicNoWifi = MyApplication.getInstance().getBooleanValue("isShowpicNoWifi", true);
            if (isShowpicNoWifi) {//任何网络环境都允许访问图片
                Picasso.with(context).load(EncodingUtil.urlEncode(url)).placeholder(displayOptions.getPlaceholder_image())
                        .error(displayOptions.getPlaceholder_error_image()).into(imageView);
            } else {//只有wifi环境能允许访问图片
                if (NetUtil.isWifiAvailable(context)) {
                    Picasso.with(context).load(EncodingUtil.urlEncode(url)).placeholder(displayOptions.getPlaceholder_image())
                            .error(displayOptions.getPlaceholder_error_image()).into(imageView);
                }
            }
        }
    }

    public class DisplayOptions {
        private int placeholder_image;//占位图片
        private int placeholder_error_image;//加载失败图片

        public DisplayOptions(int placeholder_image, int placeholder_error_image) {
            this.placeholder_image = placeholder_image;
            this.placeholder_error_image = placeholder_error_image;
        }

        public int getPlaceholder_image() {
            return placeholder_image;
        }

        public void setPlaceholder_image(int placeholder_image) {
            this.placeholder_image = placeholder_image;
        }

        public int getPlaceholder_error_image() {
            return placeholder_error_image;
        }

        public void setPlaceholder_error_image(int placeholder_error_image) {
            this.placeholder_error_image = placeholder_error_image;
        }
    }
}
