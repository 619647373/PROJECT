/** 
 * @ClassName: EncryptUtil 
 * @Description: 
 * @author eastedge.com.cn
 * @date 2012-12-28 下午2:21:35 
 * 
 */ 
package com.ikentop.musicplayer.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author eastedge.com.cn
 *
 */
public class EncodingUtil {

	public static String encodeMD5String(String str) {
		return encode(str, "MD5");
	}

	private static String encode(String str, String method) {
		MessageDigest md = null;
		String dstr = null;
		try {
			md = MessageDigest.getInstance(method);
			md.update(str.getBytes());
			dstr = new BigInteger(1, md.digest()).toString(16);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dstr;
	}
	

	public static String md5(String s) {
		try {
			MessageDigest digest = MessageDigest
					.getInstance("MD5");
			digest.update(s.getBytes());
			byte messageDigest[] = digest.digest();

			return toHexString(messageDigest);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return "";
	}
	public static String toHexString(byte[] b) { // String to byte
		StringBuilder sb = new StringBuilder(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			sb.append(HEX_DIGITS[(b[i] & 0xf0) >>> 4]);
			sb.append(HEX_DIGITS[b[i] & 0x0f]);
		}
		return sb.toString();
	}
	private static final char HEX_DIGITS[] = { '0', '1', '2', '3', '4', '5',
		'6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
	/**
	 * SHA加密
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptSHA(byte[] data) throws Exception {

		MessageDigest sha = MessageDigest.getInstance("SHA");
		sha.update(data);

		return sha.digest();

	}
	public static String toUtf_8String(String str) {
		try {
			byte[] buff = str.getBytes("utf-8");

			return new String(buff, "utf-8");

		} catch (Exception e) {
			// TODO: handle exception
			LogUtil.e(e.getMessage());
		}
		return str;

	}

	public static byte[] getUtf_8bytes(String str) {
		try {
			byte[] buff = str.getBytes("utf-8");

			return buff;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtil.e(e.getMessage());
		}
		return null;
	}

	public static String urlEncode(String src) {
		try {
			String zhPattern = "[\\u4e00-\\u9fa5]+";
			src = src.replaceAll(" ", "%20");// 对空字符串进行处理  
	        Pattern p = Pattern.compile(zhPattern);
	        Matcher m = p.matcher(src);
	        StringBuffer b = new StringBuffer();
	        while (m.find()) {  
	            m.appendReplacement(b, URLEncoder.encode(m.group(0), "UTF-8"));
	        }  
	        m.appendTail(b);  
	        return b.toString();  
		} catch (Exception e) {
			LogUtil.e(e.getMessage());
			return "";
		}
	}

	public static String urlDeocde(String src) {
		try {
			if (src.indexOf("%20") > -1) {
				src = src.replace("%20", "+");
			}
			String str = URLDecoder.decode(src, "UTF-8");
			return str;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public static String cast2String(byte[] data){
		String result=null;
		try {
			 result=new String(data, 0, data.length, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			
		}
		return result;
	}
	
	/**
     * 字符转换从UTF-8到GBK
     * 
     * @param gbkStr
     * @return
     */
//    public static byte[] getUTF8toGBKString(String gbkStr) {
//        int n = gbkStr.length();
//        byte[] utfBytes = new byte[3 * n];
//        int k = 0;
//        for (int i = 0; i < n; i++) {
//            int m = gbkStr.charAt(i);
//            if (m < 128 && m >= 0) {
//                utfBytes[k++] = (byte) m;
//                continue;
//            }
//            utfBytes[k++] = (byte) (0xe0 | (m >> 12));
//            utfBytes[k++] = (byte) (0x80 | ((m >> 6) & 0x3f));
//            utfBytes[k++] = (byte) (0x80 | (m & 0x3f));
//        }
//        if (k < utfBytes.length) {
//            byte[] tmp = new byte[k];
//            System.arraycopy(utfBytes, 0, tmp, 0, k);
//            return tmp;
//        }
//        return utfBytes;
//    }
}
