/** 
 * @ClassName: IToast 
 * @Description: 
 * @author eastedge.com.cn
 * @date 2013-6-3 上午11:53:43 
 * 
 */
package com.ikentop.musicplayer.utils;

import android.view.Gravity;
import android.widget.Toast;

import com.ikentop.musicplayer.MyApplication;

/**
 * @{# IToast.java Create on 2013-6-3 上午11:53:43
 * @Description:
 * @author eastedge.com.cn <a href="mailto:jusng@foxmail.com">jusng</a>
 */

public class IToast {
	private static Toast mToast;

	// public static void makeText(String text){
	// Toast.makeText(IApp.getInstance().getApplicationContext(), text,
	// 0).show();
	// }

	public static void makeText(String text, int time) {
		Toast.makeText(MyApplication.getInstance().getApplicationContext(), text, time)
				.show();
	}

	public static void makeText(int id) {
		Toast.makeText(MyApplication.getInstance().getApplicationContext(), id, Toast.LENGTH_SHORT)
				.show();
	}

	public static void makeText(String text) {
		if (mToast == null) {
			mToast = Toast.makeText(MyApplication.getInstance().getApplicationContext(),
					text, Toast.LENGTH_SHORT);
		} else {
			mToast.setText(text);
		}
		mToast.setGravity(Gravity.CENTER, 0, 0);
		mToast.show();
	}
}
