/** 
 * @ClassName: NetUtil 
 * @Description: 
 * @author eastedge.com.cn
 * @date 2013-7-10 上午10:33:14 
 * 
 */ 
package com.ikentop.musicplayer.utils;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

/**    
 * @{# NetUtil.java Create on 2013-7-10 上午10:33:14      
 * @Description: 
 * @author eastedge.com.cn <a href="mailto:jusng@foxmail.com">jusng</a>      
 */

public class NetUtil {
	/***************************************************
	 * 检查wifi网络连接
	 * @param context 上下文
	 * @return true 网络正常 fasle 无网络.并弹出Dialog提示设置网络
	 */
	public static  boolean isWifiAvailable(Context context){
		ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = manager.getActiveNetworkInfo();
		if (info == null || !info.isConnected()) {
			return false;
		}
		if (info.isRoaming()) {
			return true;
		}
		int netType = info.getType();
		if (info.isConnected()&&netType == ConnectivityManager.TYPE_WIFI) {
			return true;
		}
		return false;
		
	}
	/**
	 * 检查当前网络连接是否正常
	 * 
	 * @param context
	 * @return
	 */
	public  static boolean hasNetwork(Context context) {
		ConnectivityManager con = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo workinfo = con.getActiveNetworkInfo();
		if (workinfo == null || !workinfo.isAvailable()||!workinfo.isConnected()) {
			return false;
		}
		return true;
	}
	/***************************************
	* 无网络Dialog 无网络时调用
	* @return Dialog 设置网络  或 取消
	*/
	public static AlertDialog getNoInternetDg(final Context context){
		//无网络Dialog
		AlertDialog internetDg = new AlertDialog.Builder(context).
	           setTitle("提示"). 
	           setMessage("无网络连接"). 
	           setIcon(android.R.drawable.stat_notify_error).setNegativeButton("取消", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						
						dialog.cancel();						
					}
				}).setPositiveButton("设置", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.cancel();
						if(context instanceof Activity){
							if(android.os.Build.VERSION.SDK_INT > 10 ){
							     //3.0以上打开设置界面，也可以直接用ACTION_WIRELESS_SETTINGS打开到wifi界面
								((Activity) context).startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS),1);
							} else {
								((Activity) context).startActivityForResult(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS),1);
							}
							
						}
					}
				}).create();
		return internetDg;
	}
	
	/**
	 * 检测是否有sim卡
	 * @param context
	 * @return
	 */
	public static boolean hasSIM(Context context){
		TelephonyManager mTelephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		int simState = mTelephonyManager.getSimState();
		if(TelephonyManager.SIM_STATE_ABSENT == simState){
			return false;
		}
		return true;
	}
}
