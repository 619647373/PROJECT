package com.ikentop.musicplayer.utils;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Handler;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author LUZI
 * @ClassName: PlayerOnlineUtil
 * @Description: TODO(流媒体音乐播放工具类)
 * @date 2016/11/03
 */

public class PlayerOnlineUtil implements OnBufferingUpdateListener, OnCompletionListener,
        OnPreparedListener {

	public MediaPlayer mediaPlayer;
	private SeekBar seekBar;
	private TextView startTime,endTime;
	private Timer mTimer = new Timer();

	public PlayerOnlineUtil(SeekBar seekBar, TextView startTime, TextView endTime) {
		super();
		this.seekBar = seekBar;
		this.startTime = startTime;
		this.endTime = endTime;
		try {
			mediaPlayer = new MediaPlayer();
			mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
			mediaPlayer.setOnBufferingUpdateListener(this);
			mediaPlayer.setOnPreparedListener(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
		mTimer.schedule(timerTask, 0, 1000);
	}

	TimerTask timerTask = new TimerTask() {

		@Override
		public void run() {
			if (mediaPlayer == null)
				return;
			if (mediaPlayer.isPlaying() && seekBar.isPressed() == false) {
				handler.sendEmptyMessage(0);
			}
		}
	};

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			int position = mediaPlayer.getCurrentPosition();//当前播放时间
			int duration = mediaPlayer.getDuration();//音乐总时间
			if (duration > 0) {
				long pos = seekBar.getMax() * position / duration;
				seekBar.setProgress((int) pos);//播放进度
				startTime.setText(getStringTime(position/1000));
				endTime.setText(getStringTime(duration/1000));
			}
		};
	};

	public void play() {
		mediaPlayer.start();
	}

	/**
	 *
	 * @param url
	 * 拿到url加载音乐.
	 */
	public void playUrl(String url) {
		try {
			mediaPlayer.reset();
			mediaPlayer.setDataSource(url);
			mediaPlayer.prepare();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	//暂停播放
	public void pause() {
		mediaPlayer.pause();
	}

	//停止播放
	public void stop() {
		if (mediaPlayer != null) {
			mediaPlayer.stop();
			mediaPlayer.release();
			mediaPlayer = null;
		}
	}

	//是否正在播放
	public boolean isPlaying(){
		return !mediaPlayer.isPlaying();
	}

	//是否循环
	public void Looping(boolean loop) {
		mediaPlayer.setLooping(loop);
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		mp.start();
		Log.e("mediaPlayer", "onPrepared");
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		Log.e("mediaPlayer", "onCompletion");
	}

	/**
	 * 实时更新
	 */
	@Override
	public void onBufferingUpdate(MediaPlayer mp, int percent) {
		seekBar.setSecondaryProgress(percent);
		int currentProgress = seekBar.getMax()
				* mediaPlayer.getCurrentPosition() / mediaPlayer.getDuration();
		Log.e(currentProgress + "% play", percent + " buffer");
	}


	/**
	 * 时间转换
	 */
	public static String getStringTime(int cnt){
		int hour = cnt/3600;
		int min = cnt % 3600 / 60;
		int second = cnt % 60;
		return String.format(Locale.CHINA,"%02d:%02d",min,second);
	}

}
