package com.ikentop.musicplayer.utils;

import android.annotation.SuppressLint;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

@SuppressLint("SimpleDateFormat")
public class SimpleDateUtils {
	private static final String DATE_LATE = "yyyy-MM-dd";
	private static final String TIME_LATE = "HH:mm:ss:SSS";
	private static final String DATE_TIME_LATE = "yyyy-MM-dd HH:mm:ss.SSS";
	private static final String DATE_TIME_LATE2 = "yyyy-MM-dd HH:mm:ss";
	private static final String DATE_TIME_LATE3 = "yyyyMMddHHmmss";
	private static final String DATE_TIME_LATE4 = "MM-dd HH:mm:ss";
	private static final String Y_M_LATE = "yyyy-MM";
	private static final String Y_LATE = "yyyy";
	private static final String M_D_LATE = "MM-dd";
	private static final String M_D_LATE1 = "MM.dd";
	private static final String M_D_LATE2 = "M.d";
	private static final String H_M_LATE = "HH:mm";
	private static final String H_M_S_LATE = "HH:mm:ss";

	private static final String DATE_LATE_CH = "yyyy年MM月dd日";
	private static final String Y_M_LATE_CH = "yyyy年MM月";
	private static final String Y_LATE1_CH = "yyyy年";

	private static final String YY_MM_DD = "yyyyMMdd";

	/**one hour in ms*/
	private static final int ONE_HOUR = 1 * 60 * 60 * 1000;
	/**one minute in ms*/
	private static final int ONE_MIN = 1 * 60 * 1000;
	/**one second in ms*/
	private static final int ONE_SECOND = 1 * 1000;

	public static String getDateString(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_LATE,
				Locale.getDefault());
		return dateFormat.format(date);
	}

	public static Date getDateByString(String date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_LATE,
				Locale.getDefault());
		try {
			return timeFormat.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static Date getTimeBysString(String time) throws ParseException {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_LATE,
				Locale.getDefault());
		return timeFormat.parse(time);
	}

	public static String getTimeString(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(TIME_LATE,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static Date getTimeByString(String time) throws ParseException {
		SimpleDateFormat timeFormat = new SimpleDateFormat(TIME_LATE,
				Locale.getDefault());
		return timeFormat.parse(time);
	}

	public static String getDateTimeString(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static String getDateTimeString2(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE2,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static String getDateTimeMDHMS(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE4,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static String getDateTimeString3(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE3,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static Date getDateTimeByString(String time) throws ParseException {
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE,
				Locale.getDefault());
		return timeFormat.parse(time);
	}

	public static String getMDString(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(M_D_LATE,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	public static String getYMString(Date date) {
		SimpleDateFormat ymFormat = new SimpleDateFormat(Y_M_LATE,
				Locale.getDefault());
		return ymFormat.format(date);
	}

	public static String getYMCHString(Date date) {
		SimpleDateFormat ymFormat = new SimpleDateFormat(Y_M_LATE_CH,
				Locale.getDefault());
		return ymFormat.format(date);
	}

	public static String getYMDCHString(Date date) {
		SimpleDateFormat ymFormat = new SimpleDateFormat(DATE_LATE_CH,
				Locale.getDefault());
		return ymFormat.format(date);
	}

	public static String getYCHString(Date date) {
		SimpleDateFormat ymFormat = new SimpleDateFormat(Y_LATE1_CH,
				Locale.getDefault());
		return ymFormat.format(date);
	}


	public static Date getDateYMByString(String time) throws ParseException {
		SimpleDateFormat ymFormat = new SimpleDateFormat(Y_M_LATE,
				Locale.getDefault());
		return ymFormat.parse(time);
	}

	public static String getYString(Date date) {
		SimpleDateFormat yFormat = new SimpleDateFormat(Y_LATE,
				Locale.getDefault());
		return yFormat.format(date);
	}

	public static Date getDateYByString(String time) throws ParseException {
		SimpleDateFormat yFormat = new SimpleDateFormat(Y_LATE,
				Locale.getDefault());
		return yFormat.parse(time);
	}

	public static String getHMString(Date date) {
		SimpleDateFormat yFormat = new SimpleDateFormat(H_M_LATE,
				Locale.getDefault());
		return yFormat.format(date);
	}

	public static Date getDateByHMString(String time) throws ParseException {
		SimpleDateFormat yFormat = new SimpleDateFormat(H_M_LATE,
				Locale.getDefault());
		return yFormat.parse(time);
	}

	public static String getHMSString(Date date) {
		SimpleDateFormat yFormat = new SimpleDateFormat(H_M_S_LATE,
				Locale.getDefault());
		return yFormat.format(date);
	}

	public static Date getDateHMSString(String time) throws ParseException {
		SimpleDateFormat yFormat = new SimpleDateFormat(H_M_S_LATE,
				Locale.getDefault());
		return yFormat.parse(time);
	}

	public static Date getDateYYMMDDtring(String time) throws ParseException {
		SimpleDateFormat yFormat = new SimpleDateFormat(YY_MM_DD,
				Locale.getDefault());
		return yFormat.parse(time);
	}

	public static boolean isSameDate(Date date1, Date date2) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date1);
		int year1 = calendar.get(Calendar.YEAR);
		int month1 = calendar.get(Calendar.MONTH);
		int day1 = calendar.get(Calendar.DAY_OF_MONTH);
		calendar.setTime(date2);
		int year2 = calendar.get(Calendar.YEAR);
		int month2 = calendar.get(Calendar.MONTH);
		int day2 = calendar.get(Calendar.DAY_OF_MONTH);
		return year1 == year2 && month1 == month2 && day1 == day2;
	}

	public static Date getDateByTimeZone(String fromTimeZong,
                                         String toTimeZone, Date fromDate) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(DATE_TIME_LATE);
		format.setTimeZone(TimeZone.getTimeZone(fromTimeZong));
		String tempString = format.format(fromDate);
		format.setTimeZone(TimeZone.getTimeZone(toTimeZone));
		tempString = format.format(fromDate);

		SimpleDateFormat format2 = new SimpleDateFormat(DATE_TIME_LATE);
		Date toDate = format2.parse(tempString);
		return toDate;
	}

	public static Date getDate() {
		Date date = new Date();
		date = new Date(System.currentTimeMillis());
		return date;
	}

	/**
	 *换算HH/MM时间
	 */
	public static String getHMStrings() {
		SimpleDateFormat yFormat = new SimpleDateFormat(H_M_LATE,
				Locale.getDefault());
		return yFormat.format(getDate());
	}

	public static int getDaysByYearMonth(int year, int month) {

		Calendar a = Calendar.getInstance();
		a.set(Calendar.YEAR, year);
		a.set(Calendar.MONTH, month - 1);
		a.set(Calendar.DATE, 1);
		a.roll(Calendar.DATE, -1);
		int maxDate = a.get(Calendar.DATE);
		return maxDate;
	}

	public static String getMDString1(Date date) {
		SimpleDateFormat timeFormat = new SimpleDateFormat(M_D_LATE2,
				Locale.getDefault());
		return timeFormat.format(date);
	}

	//时间戳转换成字符串
	public static String getDateToString(Long time) {
		if(time == null){
			time=(long)0;
		}
		long msl=(long)time*1000;//TMD不乘1000会变成1970
//		时间戳转换成字符串
		SimpleDateFormat timeFormat = new SimpleDateFormat(DATE_TIME_LATE2,
				Locale.getDefault());
		return timeFormat.format(msl);
	}

	/**HH:mm:ss*/
	public static String formatTime(long ms) {
		StringBuilder sb = new StringBuilder();
		int hour = (int) (ms / ONE_HOUR);
		int min = (int) ((ms % ONE_HOUR) / ONE_MIN);
		int sec = (int) (ms % ONE_MIN) / ONE_SECOND;
		if (hour == 0) {
//			sb.append("00:");
		} else if (hour < 10) {
			sb.append("0").append(hour).append(":");
		} else {
			sb.append(hour).append(":");
		}
		if (min == 0) {
			sb.append("00:");
		} else if (min < 10) {
			sb.append("0").append(min).append(":");
		} else {
			sb.append(min).append(":");
		}
		if (sec == 0) {
			sb.append("00");
		} else if (sec < 10) {
			sb.append("0").append(sec);
		} else {
			sb.append(sec);
		}
		return sb.toString();
	}

	/**
	 *计算年龄
	 */
	public static int getAge(Date birthDay) throws Exception {
		Calendar cal = Calendar.getInstance();

		if (cal.before(birthDay)) {
			throw new IllegalArgumentException(
					"The birthDay is before Now.It's unbelievable!");
		}

		int yearNow = cal.get(Calendar.YEAR);
		int monthNow = cal.get(Calendar.MONTH);
		int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
		cal.setTime(birthDay);

		int yearBirth = cal.get(Calendar.YEAR);
		int monthBirth = cal.get(Calendar.MONTH);
		int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);

		int age = yearNow - yearBirth;

		if (monthNow <= monthBirth) {
			if (monthNow == monthBirth) {
				//monthNow==monthBirth
				if (dayOfMonthNow < dayOfMonthBirth) {
					age--;
				} else {
					//do nothing
				}
			} else {
				//monthNow>monthBirth
				age--;
			}
		} else {
			//monthNow<monthBirth
			//donothing
		}

		return age;
	}

}
