package com.ikentop.musicplayer.weight;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ikentop.musicplayer.R;


/**
 * Created by cundong on 2015/10/9.
 * <p/>
 * RecyclerView的HeaderView，简单的展示一个TextView
 */
public class SampleHeader extends RelativeLayout {

    public SampleHeader(final Context context,String title) {
        super(context);
        init(context);
        TextView person_video_list_honey_count= (TextView) findViewById(R.id.person_video_list_honey_count);
        person_video_list_honey_count.setText(title);
        person_video_list_honey_count.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, "SampleHeader", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public SampleHeader(final Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public SampleHeader(final Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public void init(Context context) {

        inflate(context, R.layout.sample_header, this);
    }
}